﻿using Assets.Scripts.Player;
using BrendonBanville.Tools;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts.Environment.Interactable
{
    public class OreVein : BasicSwitch, IInteractable
    {
        [SerializeField] List<GameObject> orePrefabs;
        [SerializeField] List<Transform> dropPoints;
        bool veinMined = false;

        /// <summary>
        /// What happens when the player interacts with this object
        /// </summary>
        public override void Interact()
        {
            if (CanUse())
            {
                if (IsOn)
                {
                    IsOn = false;
                    veinMined = true;
                }

                Switchable.SetActive(IsOn);

                if (orePrefabs.Count > 0)
                {
                    if (dropPoints.Count > 0)
                    {
                        //Instantiate(orePrefabs.Random(), dropPoints.Random());
                        Instantiate(orePrefabs.Random(), this.transform.position + new Vector3(0, 6, 0), this.transform.rotation);
                    }
                }

                if (Open)
                {
                    AudioSource.PlayClipAtPoint(Open, transform.position);
                }
            }
            else
            {
                if (Error)
                {
                    AudioSource.PlayClipAtPoint(Error, transform.position);
                }
            }
        }

        /// <summary>
        /// Checks if the player can pull the switch
        /// </summary>
        /// <returns></returns>
        public override bool CanUse()
        {
            if ((string.IsNullOrEmpty(RequiredKey) || PlayerInventory.HasItem(RequiredKey)) && IsOn)
            {
                return true;
            }

            return false;
        }
    }
}
