﻿using BrendonBanville.Tools;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace Assets.Scripts
{
    public class ObjectiveTracker : PersistentSingleton<ObjectiveTracker>
    {
        public List<Objective> Objectives;
        public Dictionary<string, Objective> objectivesList = new Dictionary<string, Objective>();

        public TextMeshProUGUI objectiveText;

        protected override void Awake()
        {
            for (int i = 0; i < Objectives.Count; ++i)
            {
                /// Save objective into dictionary
                objectivesList.Add(Objectives[i].Name, Objectives[i]);
            }
        }

        CopperCart _coppercart;

        // Start is called before the first frame update
        void Start()
        {
            _coppercart = GameObject.FindGameObjectWithTag("Minecart").GetComponent<CopperCart>();

            UpdateObjectives();
        }

        void Update()
        {
            //UpdateObjectives();
            objectiveText.text = "Collect Copper:   " + _coppercart.oreCount + " / " + _coppercart.oreRequired;
        }

        public Objective FindObjective(string objectiveToCheck)
        {
            foreach (Objective objective in Objectives)
            {
                if (objectiveToCheck == objective.Name)
                {
                    return objective;
                }
                else
                {
                    break;
                }
            }

            return null;
        }

        public void UpdateObjectives()
        {
            foreach (Objective objective in Objectives)
            {
                if (objective.IsActive)
                {
                    objectiveText.text = objective.ObjectiveMessage;
                }
            }
        }
    }

    [Serializable]
    public class Objective
    {
        public string Name;
        public bool IsActive;
        public string ObjectiveMessage;
    }
}