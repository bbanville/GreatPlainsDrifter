﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts
{
    public class ObjectiveUpdater : MonoBehaviour
    {
        public List<ObjectiveUpdateItem> objectivesToUpdate;

        ObjectiveTracker _tracker;

        // Start is called before the first frame update
        void Start()
        {
            _tracker = GameObject.FindGameObjectWithTag("Objectives").GetComponent<ObjectiveTracker>();
        }

        void OnTriggerEnter(Collider col)
        {
            if (col.tag == "Minecart")
            {
                foreach (ObjectiveUpdateItem update in objectivesToUpdate)
                {
                    Debug.Log("Reached the Inside");
                    Objective objective = _tracker.FindObjective(update.objectiveToUpdate);

                    if (objective != null)
                    {
                        objective.IsActive = update.activityToSet;
                    }
                }

                _tracker.UpdateObjectives();
            }
        }
    }

    [Serializable]
    public class ObjectiveUpdateItem
    {
        public string objectiveToUpdate;
        public bool activityToSet;
    }
}
