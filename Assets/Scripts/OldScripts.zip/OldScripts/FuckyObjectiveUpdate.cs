﻿using Assets.Scripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FuckyObjectiveUpdate : MonoBehaviour
{
    Vector3 updatePosition = new Vector3(6.86f, 6.756f, -82.67f);

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (this.transform.position == updatePosition)
        {
            var _tracker = GameObject.FindGameObjectWithTag("Objectives").GetComponent<ObjectiveTracker>();
            Objective objective;

            var update = new ObjectiveUpdateItem();
            update.objectiveToUpdate = "ProtectMinecart";
            update.activityToSet = false;

            objective = _tracker.FindObjective(update.objectiveToUpdate);

            update.objectiveToUpdate = "ActivateMinecart2";
            update.activityToSet = true;

            objective = _tracker.FindObjective(update.objectiveToUpdate);
        }
    }
}
