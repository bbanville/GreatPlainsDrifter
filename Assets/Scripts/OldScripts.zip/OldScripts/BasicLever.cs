﻿using Assets.Scripts.Player;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts.Environment.Interactable
{
    public class BasicLever : InteractableObject, IInteractable
    {
        Animator _animator;

        [SerializeField] Animator _objectAnimator;
        [SerializeField] string animName;

        [SerializeField] string RequiredKey;
        [SerializeField] bool IsOn;

        [SerializeField] AudioClip Error;
        [SerializeField] AudioClip Open;

        // Start is called before the first frame update
        void Start()
        {
            _animator = GetComponentInParent<Animator>();
        }

        // Update is called once per frame
        void Update()
        {

        }

        /// <summary>
        /// What happens when the player interacts with this object
        /// </summary>
        public virtual void Interact()
        {
            if (CanUse())
            {
                if (IsOn)
                {
                    _animator.Play("Deactivate");
                }
                else
                {
                    _animator.Play("Activate");
                    _objectAnimator.Play(animName);

                    /// Temporary solution
                    if (this.name == "Prop_Track_Lever_01")
                    {
                        var _tracker = GameObject.FindGameObjectWithTag("Objectives").GetComponent<ObjectiveTracker>();
                        Objective objective;

                        objective = _tracker.FindObjective("ActivateMinecart");
                        if (objective != null)
                        {
                            objective.IsActive = false;
                        }
                        else
                        {
                            Debug.LogWarning("Couldn't find an objective with name ActivateMinecart");
                        }

                        objective = _tracker.FindObjective("ProtectMinecart");
                        if (objective != null)
                        {
                            objective.IsActive = true;
                        }
                        else
                        {
                            Debug.LogWarning("Couldn't find an objective with name ProtectMinecart");
                        }
                    }

                    if (this.name == "Prop_Track_Lever_01 (1)")
                    {
                        var _tracker = GameObject.FindGameObjectWithTag("Objectives").GetComponent<ObjectiveTracker>();
                        Objective objective;

                        objective = _tracker.FindObjective("ProtectMinecart");
                        if (objective != null)
                        {
                            objective.IsActive = false;
                        }
                        else
                        {
                            Debug.LogWarning("Couldn't find an objective with name ProtectMinecart");
                        }

                        objective = _tracker.FindObjective("ActivateMinecart2");
                        if (objective != null)
                        {
                            objective.IsActive = true;
                        }
                        else
                        {
                            Debug.LogWarning("Couldn't find an objective with name ActivateMinecart2");
                        }
                    }
                    ///
                }

                IsOn = !IsOn;

                if (Open)
                {
                    AudioSource.PlayClipAtPoint(Open, transform.position);
                }
            }
            else
            {
                if (Error)
                {
                    AudioSource.PlayClipAtPoint(Error, transform.position);
                }
            }
        }

        /// <summary>
        /// Checks if the player can pull the switch
        /// </summary>
        /// <returns></returns>
        public virtual bool CanUse()
        {
            if (string.IsNullOrEmpty(RequiredKey) || PlayerInventory.HasItem(RequiredKey))
            {
                return true;
            }

            return false;
        }
    }
}
