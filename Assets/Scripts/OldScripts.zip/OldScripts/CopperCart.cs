﻿using Assets.Scripts;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CopperCart : MonoBehaviour
{
    public int oreCount = 0;
    public int oreRequired = 5;
    [SerializeField] List<GameObject> oreGroups;

    EndScreen endScreen;

    // Start is called before the first frame update
    void Start()
    {
        endScreen = GameObject.FindGameObjectWithTag("UICanvas").GetComponent<EndScreen>();
    }

    // Update is called once per frame
    void Update()
    {
        if (oreCount >= oreRequired)
        {
            endScreen.LevelComplete();
        }
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.name.Contains("Prop_Copper_Piece"))
        {
            Destroy(col.gameObject);
            oreGroups[oreCount].SetActive(true);

            oreCount++;
        }
    }
}
