﻿using UnityEngine;
using BrendonBanville.Tools;

namespace Assets.Scripts.Environment.Interactable
{
    public class WhiskeyRage : Pickup
    {
        Material tipsy;
        drunk drunkScript;

        void Start()
        {

        }

        void Update()
        {

        }

        public override void ActivatePickup()
        {
            base.ActivatePickup();

            drunkScript.material = tipsy;

            // force weapon to melee
            // and/or
            // multiply weapon damage by 10
        }
    }
}