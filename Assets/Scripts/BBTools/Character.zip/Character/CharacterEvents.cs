﻿using UnityEngine;
using System.Collections;
using BrendonBanville.Tools;

namespace BrendonBanville.Characters
{	
	/// <summary>
	/// A list of possible events used by the character
	/// </summary>
	public enum NUCharacterEventTypes
	{
		ButtonActivation,
		Jump
	}

	/// <summary>
	/// MMCharacterEvents are used in addition to the events triggered by the character's state machine, to signal stuff happening that is not necessarily linked to a change of state
	/// </summary>
	public struct NUCharacterEvent
	{
		public Character TargetCharacter;
		public NUCharacterEventTypes EventType;
		/// <summary>
		/// Initializes a new instance of the <see cref="BrendonBanville.Tools.NUCharacterEvent"/> struct.
		/// </summary>
		/// <param name="character">Character.</param>
		/// <param name="eventType">Event type.</param>
		public NUCharacterEvent(Character character, NUCharacterEventTypes eventType)
		{
			TargetCharacter = character;
			EventType = eventType;
		}

        static NUCharacterEvent e;
        public static void Trigger(Character character, NUCharacterEventTypes eventType)
        {
            e.TargetCharacter = character;
            e.EventType = eventType;
            NUEventManager.TriggerEvent(e);
        }
    } 

	/// <summary>
	/// An event fired when something takes damage
	/// </summary>
	public struct NUDamageTakenEvent
	{
		public Character AffectedCharacter;
		public GameObject Instigator;
		public float CurrentHealth;
		public float DamageCaused;
		public float PreviousHealth;

		/// <summary>
		/// Initializes a new instance of the <see cref="BrendonBanville.Tools.NUDamageTakenEvent"/> struct.
		/// </summary>
		/// <param name="affectedCharacter">Affected character.</param>
		/// <param name="instigator">Instigator.</param>
		/// <param name="currentHealth">Current health.</param>
		/// <param name="damageCaused">Damage caused.</param>
		/// <param name="previousHealth">Previous health.</param>
		public NUDamageTakenEvent(Character affectedCharacter, GameObject instigator, float currentHealth, float damageCaused, float previousHealth)
		{
			AffectedCharacter = affectedCharacter;
			Instigator = instigator;
			CurrentHealth = currentHealth;
			DamageCaused = damageCaused;
			PreviousHealth = previousHealth;
		}

        static NUDamageTakenEvent e;
        public static void Trigger(Character affectedCharacter, GameObject instigator, float currentHealth, float damageCaused, float previousHealth)
        {
            e.AffectedCharacter = affectedCharacter;
            e.Instigator = instigator;
            e.CurrentHealth = currentHealth;
            e.DamageCaused = damageCaused;
            e.PreviousHealth = previousHealth;
            NUEventManager.TriggerEvent(e);
        }
    }
}