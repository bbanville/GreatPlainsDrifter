﻿using UnityEngine;
using UnityEngine.UI;
using Opsive.UltimateCharacterController.Character;
//using Opsive.UltimateCharacterController.Demo.Objects;
using Opsive.UltimateCharacterController.Demo.UI;
using Opsive.UltimateCharacterController.Events;
using Opsive.UltimateCharacterController.Game;
using Opsive.UltimateCharacterController.Inventory;
using Opsive.UltimateCharacterController.Traits;
using Opsive.UltimateCharacterController.Utility;
using System.Collections.Generic;
using BrendonBanville.Tools;
using Assets.Scripts.Managers;
using System;
using BrendonBanville.Managers;
using UnityEngine.SceneManagement;

/// <summary>
/// The GameManager will control the objects in the scene as well as the text shown.
/// </summary>
public class LevelManager : Singleton<GameManager>
{
    /// <summary>
    /// Container for each zone within the scene.
    /// </summary>
    [Serializable]
    public class BattleZone
    {
        [Tooltip("The header text.")]
        [SerializeField] protected string m_Header;
        [Tooltip("The description text.")]
        [SerializeField] protected string m_Description;
        [Tooltip("The text that appears beneath the header requiring action.")]
        [SerializeField] protected string m_Action;
        [Tooltip("The trigger that enables the header and description text.")]
        [SerializeField] protected BattleZoneTrigger m_BattleZoneTrigger;
        [Tooltip("The objects that the trigger should enable.")]
        [SerializeField] protected MonoBehaviour[] m_EnableObjects;
        [Tooltip("The objects that the trigger should activate/deactivate.")]
        [SerializeField] protected GameObject[] m_ToggleObjects;
        [Tooltip("The target frame rate for the game.")]
        [SerializeField] protected int TargetFrameRate = 300;

        public string Header { get { return m_Header; } }
        public string Description { get { return m_Description; } }
        public string Action { get { return m_Action; } }
        public BattleZoneTrigger BattleZoneTrigger { get { return m_BattleZoneTrigger; } }
        public MonoBehaviour[] EnableObjects { get { return m_EnableObjects; } }
        public GameObject[] ToggleObjects { get { return m_ToggleObjects; } }

        private int m_Index;
        public int Index { get { return m_Index; } }

        // storage
        protected Stack<float> _savedTimeScale;
        protected bool _inventoryOpen = false;
        protected bool _pauseMenuOpen = false;
        protected int _initialMaximumLives;
        protected int _initialCurrentLives;

        /// <summary>
        /// Initializes the zone.
        /// </summary>
        /// <param name="index">The index of the BattleZone.</param>
        public void Initialize(int index)
        {
            m_Index = index;

            // Assign the spawn point so the character will know where to spawn upon death.
            var spawnPoints = m_BattleZoneTrigger.GetComponentsInChildren<SpawnPoint>();
            for (int i = 0; i < spawnPoints.Length; ++i)
            {
                spawnPoints[i].Grouping = index;
            }

            // The toggled objects should start disabled.
            for (int i = 0; i < m_ToggleObjects.Length; ++i)
            {
                m_ToggleObjects[i].SetActive(false);
            }
        }
    }

    [Tooltip("A reference to the character.")]
    [SerializeField] protected GameObject m_Character;
    #if FIRST_PERSON_CONTROLLER && THIRD_PERSON_CONTROLLER
    [Tooltip("Specifies the perspective that the character should start in if there is no perspective selection GameObject.")]
    [SerializeField] protected bool m_DefaultFirstPersonStart = true;
    #endif
    [Tooltip("Is the character allowed to free roam the scene at the very start?")]
    [SerializeField] protected bool m_FreeRoam;
    [Tooltip("Should the ItemTypes be picked up when the character spawns within free roam mode?")]
    [SerializeField] protected bool m_FreeRoamPickupItemTypes = true;
    [Tooltip("An array of ItemTypes to be picked up when free roaming.")]
    [SerializeField] protected ItemTypeCount[] m_FreeRoamItemTypeCounts;
    [Tooltip("A reference used to determine the character's perspective selection at the start.")]
    [SerializeField] protected GameObject m_PerspectiveSelection;
    [Tooltip("A reference to the panel which shows the tutorial text.")]
    [SerializeField] protected GameObject m_TextPanel;
    [Tooltip("A reference to the Text component which shows the tutorial header text.")]
    [SerializeField] protected Text m_Header;
    [Tooltip("A reference to the Text component which shows the tutorial description text.")]
    [SerializeField] protected Text m_Description;
    [Tooltip("A reference to the Text component which shows the tutorial action text.")]
    [SerializeField] protected Text m_Action;
    [Tooltip("A reference to the GameObject which shows the next zone arrow.")]
    [SerializeField] protected GameObject m_NextZoneArrow;
    [Tooltip("A reference to the GameObject which shows the previous zone arrow.")]
    [SerializeField] protected GameObject m_PreviousZoneArrow;
    [Tooltip("A list of all of the zones within the scene.")]
    [SerializeField] protected BattleZone[] m_BattleZones;
    [Tooltip("The title that should be displayed when the character is not in a zone.")]
    [SerializeField] protected string m_NoZoneTitle;
    [Tooltip("The description that should be displayed when the character is not in a zone.")]
    [SerializeField] protected string m_NoZoneDescription;
    [Tooltip("Is this manager part of an add-on?")]
    [UnityEngine.Serialization.FormerlySerializedAs("m_AddonBattleManager")]
    [SerializeField] protected bool m_AddOnBattleManager;

    public GameObject Character { get { return m_Character; } }
    public bool FreeRoam { get { return m_FreeRoam; } set { m_FreeRoam = value; } }
    public GameObject PerspectiveSelection { get { return m_PerspectiveSelection; } set { m_PerspectiveSelection = value; } }
    public BattleZone[] BattleZones { get { return m_BattleZones; } }

    private UltimateCharacterLocomotion m_CharacterLocomotion;
    private Health m_CharacterHealth;
    private Respawner m_CharacterRespawner;
    private Dictionary<BattleZoneTrigger, BattleZone> m_BattleZoneTriggers = new Dictionary<BattleZoneTrigger, BattleZone>();
    private List<int> m_ActiveZoneIndices = new List<int>();
    private int m_LastZoneIndex = -1;
    //private List<Door> m_Doors = new List<Door>();
    private int m_EnterFrame;
    private bool m_FullAccess;

    /// <summary>
    /// Initialize the default values.
    /// </summary>
    protected override void Awake()
    {
        base.Awake();

        #if !FIRST_PERSON_CONTROLLER || !THIRD_PERSON_CONTROLLER
        var battleZones = new List<BattleZone>(m_BattleZones);
        for (int i = battleZones.Count - 1; i > -1; --i) {
            // The battle zone may belong to the other perspective.
            if (battleZones[i].BattleZoneTrigger == null) {
                battleZones.RemoveAt(i);
            }
        }
        m_BattleZones = battleZones.ToArray();
        #endif
        for (int i = 0; i < m_BattleZones.Length; ++i)
        {
            if (m_BattleZones[i].BattleZoneTrigger == null)
            {
                continue;
            }

            m_BattleZones[i].Initialize(i);
            m_BattleZoneTriggers.Add(m_BattleZones[i].BattleZoneTrigger, m_BattleZones[i]);
        }

        #region Enable UI
        // Enable the UI after the character has spawned.
        m_TextPanel.SetActive(false);
        if (m_PreviousZoneArrow != null)
        {
            m_PreviousZoneArrow.SetActive(false);
        }
        if (m_NextZoneArrow != null)
        {
            m_NextZoneArrow.SetActive(false);
        }
        if (m_Action != null)
        {
            m_Action.enabled = false;
        }
        #endregion
    }

    /// <summary>
    /// Initializes the character.
    /// </summary>
    protected virtual void Start()
    {
        InitializeCharacter(m_Character, true);

        //if (!SceneManager.GetActiveScene().name.Contains("Duel") && !SceneManager.GetActiveScene().name.Contains("Menu"))
        //{
        //    SM.Outside.TransitionTo(1.0f);
        //}
    }

    /// <summary>
    /// Initializes the Game Manager with the specified character.
    /// </summary>
    /// <param name="character">The character that should be initialized/</param>
    /// <param name="teleport">Should the character be teleported to the first battle zone?</param>
    protected void InitializeCharacter(GameObject character, bool teleport)
    {
        m_Character = character;

        if (m_Character == null)
        {
            return;
        }

        m_CharacterLocomotion = m_Character.GetComponent<UltimateCharacterLocomotion>();
        m_CharacterHealth = m_Character.GetComponent<Health>();
        m_CharacterRespawner = m_Character.GetComponent<Respawner>();

        // Disable the components if the character is null. This allows for free roaming within the scene.
        if (m_FreeRoam)
        {
            m_FullAccess = true;
            if (m_PerspectiveSelection != null)
            {
                m_PerspectiveSelection.SetActive(false);
            }

            var uiZones = GetComponentsInChildren<UIZone>();
            for (int i = 0; i < uiZones.Length; ++i)
            {
                uiZones[i].enabled = false;
            }

            //// All of the doors should be opened with free roam.
            //for (int i = 0; i < m_Doors.Count; ++i)
            //{
            //    m_Doors[i].CloseOnTriggerExit = false;
            //    m_Doors[i].OpenClose(true, true, false);
            //}

            // The enable objects should be enabled.
            for (int i = 0; i < m_BattleZones.Length; ++i)
            {
                for (int j = 0; j < m_BattleZones[i].EnableObjects.Length; ++j)
                {
                    m_BattleZones[i].EnableObjects[j].enabled = true;
                }
            }

            // The character needs to be assigned to the camera.
            var camera = UnityEngineUtility.FindCamera(null);
            var cameraController = camera.GetComponent<Opsive.UltimateCharacterController.Camera.CameraController>();
            cameraController.Character = m_Character;

            // The character doesn't start out with any items.
            if (m_FreeRoamItemTypeCounts != null && m_FreeRoamPickupItemTypes)
            {
                var inventory = m_Character.GetComponent<InventoryBase>();
                if (inventory != null)
                {
                    for (int i = 0; i < m_FreeRoamItemTypeCounts.Length; ++i)
                    {
                        if (m_FreeRoamItemTypeCounts[i].ItemType == null)
                        {
                            continue;
                        }
                        inventory.PickupItemType(m_FreeRoamItemTypeCounts[i].ItemType, m_FreeRoamItemTypeCounts[i].Count, -1, true, false);
                    }
                }
            }

            Opsive.UltimateCharacterController.Events.EventHandler.ExecuteEvent(m_Character, "OnCharacterSnapAnimator");
            enabled = false;
            return;
        }

        // The cursor needs to be visible.
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;

        #if FIRST_PERSON_CONTROLLER && THIRD_PERSON_CONTROLLER
        // Show the perspective selection menu.
        if (m_PerspectiveSelection != null)
        {
            // The character should be disabled until the perspective is set.
            m_CharacterLocomotion.SetActive(false, true);

            m_PerspectiveSelection.SetActive(true);
        }
        else
        {
            SelectStartingPerspective(m_DefaultFirstPersonStart, teleport);
        }
        #elif FIRST_PERSON_CONTROLLER
        SelectStartingPerspective(true, teleport);
        #else
        SelectStartingPerspective(false, teleport);
        #endif
    }

    /// <summary>
    /// Keep the mouse visible when the perspective screen is active.
    /// </summary>
    private void Update()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    ///// <summary>
    ///// Registers the door with the LevelManager.
    ///// </summary>
    ///// <param name="door">The door that should be registered.</param>
    //public void RegisterDoor(Door door)
    //{
    //    m_Doors.Add(door);
    //}

    /// <summary>
    /// The character has entered a trigger zone.
    /// </summary>
    /// <param name="battleZoneTrigger">The trigger zone that the character entered.</param>
    /// <param name="other">The GameObject that entered the trigger.</param>
    public void EnteredTriggerZone(BattleZoneTrigger battleZoneTrigger, GameObject other)
    {
        var characterLocomotion = other.GetComponentInParent<UltimateCharacterLocomotion>();
        if (characterLocomotion == null || characterLocomotion.gameObject != m_Character)
        {
            return;
        }

        BattleZone battleZone;
        if (!m_BattleZoneTriggers.TryGetValue(battleZoneTrigger, out battleZone))
        {
            return;
        }

        if (m_CharacterHealth != null && m_CharacterHealth.Value == 0)
        {
            return;
        }

        ActiveBattleZone(battleZone, false);
    }

    /// <summary>
    /// Activates the specified battle zone.
    /// </summary>
    /// <param name="battlezone">The battle zone to active.</param>
    /// <param name="teleport">Should the character be teleported to the battle zone?</param>
    private void ActiveBattleZone(BattleZone battlezone, bool teleport)
    {
        #region Force Stop Ride
        // The ride ability should be force stopped.
        var ride = m_CharacterLocomotion.GetAbility<Opsive.UltimateCharacterController.Character.Abilities.Ride>();
        if (ride != null && ride.IsActive)
        {
            m_CharacterLocomotion.TryStopAbility(ride, true);
        }
        #endregion

        if (m_ActiveZoneIndices.Count == 0 || m_ActiveZoneIndices[m_ActiveZoneIndices.Count - 1] != battlezone.Index)
        {
            m_ActiveZoneIndices.Add(battlezone.Index);
        }
        m_LastZoneIndex = battlezone.Index;
        ShowText(battlezone.Header, battlezone.Description, battlezone.Action);
        if (m_PreviousZoneArrow != null)
        {
            m_PreviousZoneArrow.SetActive(battlezone.Index != 0);
        }
        if (m_NextZoneArrow != null)
        {
            m_NextZoneArrow.SetActive(battlezone.Index != m_BattleZones.Length - 1);
        }
        m_EnterFrame = Time.frameCount;
        for (int i = 0; i < battlezone.EnableObjects.Length; ++i)
        {
            battlezone.EnableObjects[i].enabled = true;
        }
        for (int i = 0; i < battlezone.ToggleObjects.Length; ++i)
        {
            battlezone.ToggleObjects[i].SetActive(true);
        }

        //// When the character reaches the outside section all doors should be unlocked.
        //if (!m_AddOnBattleManager && !m_FullAccess && battlezone.Index >= m_BattleZones.Length - 6)
        //{
        //    for (int i = 0; i < m_Doors.Count; ++i)
        //    {
        //        m_Doors[i].CloseOnTriggerExit = false;
        //        m_Doors[i].OpenClose(true, true, false);
        //    }
        //    m_FullAccess = true;
        //}

        if (teleport)
        {
            var position = Vector3.zero;
            var rotation = Quaternion.identity;
            SpawnPointManager.GetPlacement(m_Character, battlezone.Index, ref position, ref rotation);
            m_CharacterLocomotion.SetPositionAndRotation(position, rotation, true);
        }

        // Set the group after the state so the default state doesn't override the grouping value.
        m_CharacterRespawner.Grouping = battlezone.Index;
    }

    /// <summary>
    /// The character has exited a trigger zone.
    /// </summary>
    /// <param name="battleZoneTrigger">The trigger zone that the character exited.</param>
    public void ExitedTriggerZone(BattleZoneTrigger battleZoneTrigger)
    {
        BattleZone battleZone;
        if (!m_BattleZoneTriggers.TryGetValue(battleZoneTrigger, out battleZone))
        {
            return;
        }
        for (int i = 0; i < battleZone.ToggleObjects.Length; ++i)
        {
            battleZone.ToggleObjects[i].SetActive(false);
        }
        m_ActiveZoneIndices.Remove(battleZone.Index);

        // Show standard text if the battle zone isn't the last battle zone.
        if (m_ActiveZoneIndices.Count == 0 && (m_AddOnBattleManager || battleZone.Index != m_BattleZones.Length - 1) && m_EnterFrame != Time.frameCount)
        {
            ShowText(m_NoZoneTitle.Replace("{AssetName}", AssetInfo.Name), m_NoZoneDescription, string.Empty);
        }
        else if (m_ActiveZoneIndices.Count > 0 && m_LastZoneIndex != m_ActiveZoneIndices[m_ActiveZoneIndices.Count - 1])
        {
            ActiveBattleZone(m_BattleZones[m_ActiveZoneIndices[m_ActiveZoneIndices.Count - 1]], false);
        }
    }

    /// <summary>
    /// Teleports the character to the next or pervious zone.
    /// </summary>
    /// <param name="next">Should the character be teleported to the next zone? If false the previous zone will be used.</param>
    public void Teleport(bool next)
    {
        var targetIndex = Mathf.Clamp(m_LastZoneIndex + (next ? 1 : -1), 0, m_BattleZones.Length - 1);
        if (m_ActiveZoneIndices.Count > 0 && targetIndex == m_ActiveZoneIndices[m_ActiveZoneIndices.Count - 1])
        {
            return;
        }

        ActiveBattleZone(m_BattleZones[targetIndex], true);
    }

    /// <summary>
    /// Sets the starting perspective on the character.
    /// </summary>
    /// <param name="firstPersonPerspective">Should the character start in a first person perspective?</param>
    /// <param name="teleport">Should the character be teleported to the battle zone?</param>
    public void SelectStartingPerspective(bool firstPersonPerspective)
    {
        SelectStartingPerspective(firstPersonPerspective, true);
    }

    /// <summary>
    /// Sets the starting perspective on the character.
    /// </summary>
    /// <param name="firstPersonPerspective">Should the character start in a first person perspective?</param>
    /// <param name="teleport">Should the character be teleported to the battle zone?</param>
    protected void SelectStartingPerspective(bool firstPersonPerspective, bool teleport)
    {
        m_CharacterLocomotion.SetActive(true, true);

        // Set the perspective on the camera.
        var camera = UnityEngineUtility.FindCamera(null);
        var cameraController = camera.GetComponent<Opsive.UltimateCharacterController.Camera.CameraController>();
        // Ensure the camera starts with the correct view type.
        cameraController.FirstPersonViewTypeFullName = "Opsive.UltimateCharacterController.FirstPersonController.Camera.ViewTypes.Combat";
        cameraController.ThirdPersonViewTypeFullName = "Opsive.UltimateCharacterController.ThirdPersonController.Camera.ViewTypes.Adventure";
        cameraController.SetPerspective(firstPersonPerspective, true);
        cameraController.Character = m_Character;

        // Set the starting position.
        m_LastZoneIndex = -1;
        ActiveBattleZone(m_BattleZones[0], teleport);

        // The cursor should be hidden to start the game.
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        enabled = false;

        // The character and camera are ready to go - disable the perspective selection panel.
        if (m_PerspectiveSelection != null)
        {
            m_PerspectiveSelection.SetActive(false);
        }
    }

    /// <summary>
    /// Shows the text in the UI with the specified header and description.
    /// </summary>
    /// <param name="header">The header that should be shown.</param>
    /// <param name="description">The description that should be shown.</param>
    /// <param name="action">The action that should be shown.</param>
    private void ShowText(string header, string description, string action)
    {
        if (string.IsNullOrEmpty(header))
        {
            m_TextPanel.SetActive(false);
            return;
        }

        m_TextPanel.SetActive(true);
        m_Header.text = "--- " + header + " ---";
        m_Description.text = description.Replace("{AssetName}", AssetInfo.Name);
        if (m_Action != null)
        {
            m_Action.text = action;
            m_Action.enabled = !string.IsNullOrEmpty(action);
        }
    }
}